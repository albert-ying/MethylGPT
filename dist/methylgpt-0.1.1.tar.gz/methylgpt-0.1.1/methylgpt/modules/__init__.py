import sys
sys.path.append("scGPT")

# Import scGPT

import scGPT