# A potential monitor helper class/mixin to track the syncronization between
# in-memory objects and on-disk files for DataBank.
