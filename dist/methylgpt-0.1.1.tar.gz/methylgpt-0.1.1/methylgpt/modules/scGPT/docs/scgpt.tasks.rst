scgpt.tasks package
===================

Submodules
----------

scgpt.tasks.cell\_emb module
----------------------------

.. automodule:: scgpt.tasks.cell_emb
   :members:
   :undoc-members:
   :show-inheritance:

scgpt.tasks.grn module
----------------------

.. automodule:: scgpt.tasks.grn
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: scgpt.tasks
   :members:
   :undoc-members:
   :show-inheritance:
