import sys
sys.path.append("../modules/scGPT")

# Import scGPT
import scGPT