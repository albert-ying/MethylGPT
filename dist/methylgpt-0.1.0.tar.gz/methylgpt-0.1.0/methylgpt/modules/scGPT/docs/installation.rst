installation
================

Please follow the instructions on the project [GitHub page](https://github.com/bowang-lab/scGPT).